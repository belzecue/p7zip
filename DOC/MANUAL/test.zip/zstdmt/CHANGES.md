
v0.6
- update versions: zstd 1.3.8, lz4 1.8.3, brotli 1.0.7

v0.5
- use correct lizard version (v1.0)

v0.4
- added brotli, added lizard (was lz5 v2.0)
- add man pages for the sample programs
- merged the target platforms unix and windows to "programs"
- changed options, the tools are like bzip2 or gzip now
- use BSD 2-Clause license for everything

v0.3
- update to zstd 1.1.3 and lz4 1.7.5
- changed options, -T is used for the thread count now (like zstdmt of Yann)

v0.2
- update to zstd 1.1.2, lz4 1.7.4, lz5 1.5

v0.1
- first public release
